import "./App.css";

function App() {
  return (
    <div>
      <Header></Header>
      <Content></Content>
      <Footer></Footer>
    </div>
  );
}
function Header() {
  return <Title></Title>;
}

function Content() {
  return <Title></Title>;
}
function Footer() {
  return <Title />;
}

function Title() {
  return <span>lorem ipsum dolor amet!</span>;
}
export default App;
